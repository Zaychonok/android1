package stu.cn.ua.laba1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;
import java.util.Timer;

public class Game extends AppCompatActivity {

    private long START_TIME;
    private CountDownTimer mCountDownTimer;
    private boolean mTimerRunning, isPause;
    private long mTimerLeft;
    Button btn_start, btn_res, btn_back, btn1min, btn2min, btn5min, wor1, wor2, wor3, wor4;
    TextView textTime, textS, ans1, ans2, ans3, ans4,tFall;
    char[] arr;
    char[] anr;
    StringBuilder builder = new StringBuilder();
    StringBuilder builder1 = new StringBuilder();
    StringBuilder builder2 = new StringBuilder();
    StringBuilder builder3 = new StringBuilder();
    StringBuilder builder0 = new StringBuilder();
    StringBuilder builder11 = new StringBuilder();
    StringBuilder builder22 = new StringBuilder();
    StringBuilder builder33 = new StringBuilder();
    int n = 0;
    int fall = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);

        textTime = findViewById(R.id.textTime);
        textS = findViewById(R.id.textView3);
        tFall = findViewById(R.id.textFal);
        ans1 = findViewById(R.id.ans1);
        ans2 = findViewById(R.id.ans2);
        ans3 = findViewById(R.id.ans3);
        ans4 = findViewById(R.id.ans4);

        wor1 = findViewById(R.id.wor1);
        wor2 = findViewById(R.id.wor2);
        wor3 = findViewById(R.id.wor3);
        wor4 = findViewById(R.id.wor4);

        btn_start = findViewById(R.id.btnStart);
        btn_res = findViewById(R.id.btnRes);

        btn1min = findViewById(R.id.btn1);
        btn2min = findViewById(R.id.btn2);
        btn5min = findViewById(R.id.btn5);

        btn_back = findViewById(R.id.btn_back2);


        wor1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                char t = anr[n];
                char y = arr[0];
                if(y == t){
                    Toast.makeText(Game.this,"правильно",Toast.LENGTH_SHORT).show();
                    checkNum();
                    wor1.setVisibility(View.INVISIBLE);
                } else {
                    Toast.makeText(Game.this,"не правильно",Toast.LENGTH_SHORT).show();
                    fall++;
                }



            }
        });
        wor2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                char t = anr[n];
                char y = arr[1];
                if(y == t){
                    Toast.makeText(Game.this,"правильно",Toast.LENGTH_SHORT).show();
                    checkNum();
                    wor2.setVisibility(View.INVISIBLE);
                } else {
                    Toast.makeText(Game.this,"не правильно",Toast.LENGTH_SHORT).show();
                    fall++;
                }

            }
        });
        wor3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                char t = anr[n];
                char y = arr[2];
                if(y == t){
                    Toast.makeText(Game.this,"правильно",Toast.LENGTH_SHORT).show();
                    checkNum();
                    wor3.setVisibility(View.INVISIBLE);
                } else {
                    Toast.makeText(Game.this,"не правильно",Toast.LENGTH_SHORT).show();
                    fall++;
                }

            }
        });
        wor4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                char t = anr[n];
                char y = arr[3];
                if(y == t){
                    Toast.makeText(Game.this,"правильно",Toast.LENGTH_SHORT).show();
                    checkNum();
                    wor4.setVisibility(View.INVISIBLE);
                } else {
                    Toast.makeText(Game.this,"не правильно",Toast.LENGTH_SHORT).show();
                    fall++;
                }

            }
        });


        btn1min.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                START_TIME = 60000;
                mTimerLeft = START_TIME;
                textS.setText("Время");
                btn_start.setVisibility(View.VISIBLE);
                btn1min.setVisibility(View.INVISIBLE);
                btn2min.setVisibility(View.INVISIBLE);
                btn5min.setVisibility(View.INVISIBLE);
            }
        });
        btn2min.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                START_TIME = 120000;
                mTimerLeft = START_TIME;
                textS.setText("Время");
                btn_start.setVisibility(View.VISIBLE);
                btn1min.setVisibility(View.INVISIBLE);
                btn2min.setVisibility(View.INVISIBLE);
                btn5min.setVisibility(View.INVISIBLE);
            }
        });
        btn5min.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                START_TIME = 300000;
                mTimerLeft = START_TIME;
                textS.setText("Время");
                btn_start.setVisibility(View.VISIBLE);
                btn1min.setVisibility(View.INVISIBLE);
                btn2min.setVisibility(View.INVISIBLE);
                btn5min.setVisibility(View.INVISIBLE);
            }
        });

        btn_start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(mTimerRunning){
                    pauseTimer();
                } else {
                    startTimer();
                }
            }
        });

        btn_res.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                resetTimer();
            }
        });

        btn_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Game.this, MainActivity.class);
                startActivity(intent);
            }
        });


        updateCountDownText();
    }

    private  void startTimer(){
        mCountDownTimer = new CountDownTimer(mTimerLeft, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {
                mTimerLeft = millisUntilFinished;
                updateCountDownText();
            }

            @Override
            public void onFinish() {
                mTimerRunning = false;
                btn_start.setText("start");
                btn_start.setVisibility(View.INVISIBLE);
                btn_res.setVisibility(View.VISIBLE);
            }
        }.start();
        mTimerRunning = true;
        btn_start.setText("pause");
        btn_res.setVisibility(View.INVISIBLE);
        newWord();
    }

    private  void pauseTimer(){
        mCountDownTimer.cancel();
        mTimerRunning = false;
        btn_start.setText("start");
        btn_res.setVisibility(View.VISIBLE);

    }

    private  void resetTimer(){
        mTimerLeft = START_TIME;
        updateCountDownText();
        btn_res.setVisibility(View.INVISIBLE);
        btn_start.setVisibility(View.INVISIBLE);
        wor1.setVisibility(View.VISIBLE);
        wor2.setVisibility(View.VISIBLE);
        wor3.setVisibility(View.VISIBLE);
        wor4.setVisibility(View.VISIBLE);
        btn1min.setVisibility(View.VISIBLE);
        btn2min.setVisibility(View.VISIBLE);
        btn5min.setVisibility(View.VISIBLE);
        builder.setLength(0);
        builder1.setLength(0);
        builder2.setLength(0);
        builder3.setLength(0);
        builder0.setLength(0);
        builder11.setLength(0);
        builder22.setLength(0);
        builder33.setLength(0);
        ans1.setText("");
        ans2.setText("");
        ans3.setText("");
        ans4.setText("");
        wor1.setText("");
        wor2.setText("");
        wor3.setText("");
        wor4.setText("");
    }

    private  void updateCountDownText(){
        int minutes = (int) (mTimerLeft/1000)/60;
        int seconds = (int) (mTimerLeft/1000)%60;
        tFall.setText("Кол-во ошибок: " + String.valueOf(fall));
        String timeLeftForm = String.format(Locale.getDefault(), "%02d:%02d", minutes,seconds);
        textTime.setText(timeLeftForm);
    }

    private void newWord() {
        String[] words = {"дрон", "корм", "диск", "авто", "соль", "бриз", "орда", "сено", "сани", "кони"};
        int r = (int) (Math.random() * words.length);
        String word = words[r];
        String word_2 = word;
        String new_word = "";
        while (word_2.length() > 0) {
            int index = (int) (Math.random() * word_2.length());
            String ch = word_2.substring(index, index + 1);
            word_2 = word_2.replaceFirst(ch, "");
            new_word += ch;
        }

        arr = new_word.toCharArray();
        builder.append(arr[0]);
        wor1.setText(builder.toString());
        builder1.append(arr[1]);
        wor2.setText(builder1.toString());
        builder2.append(arr[2]);
        wor3.setText(builder2.toString());
        builder3.append(arr[3]);
        wor4.setText(builder3.toString());
        anr = word.toCharArray();
        builder0.append(anr[0]);
        builder11.append(anr[1]);
        builder22.append(anr[2]);
        builder33.append(anr[3]);
    }
    private  void checkNum(){
        if(n == 0){
            ans1.setText(builder0.toString());
            n++;
        } else if (n == 1){
            ans2.setText(builder11.toString());
            n++;
        } else if (n == 2){
            ans3.setText(builder22.toString());
            n++;
        } else if (n == 3){
            ans4.setText(builder33.toString());
            n++;
            Toast.makeText(Game.this,"Вы выиграли",Toast.LENGTH_LONG).show();
            Intent intent = new Intent(Game.this, MainActivity.class);
            startActivity(intent);
        }
    }
}